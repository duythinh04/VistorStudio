import { useEffect } from "react";

export default function ProjectModal({ isOpen, onClose, project, sections = [] }) {
  useEffect(() => {
    document.body.style.overflow = isOpen ? "hidden" : "auto";
    return () => {
      document.body.style.overflow = "auto";
    };
  }, [isOpen]);

  if (!isOpen || !project) return null;

  return (
    <div
      className="position-fixed top-0 start-0 w-100 h-100 bg-dark bg-opacity-75 pt-5"
      style={{ zIndex: 1050, overflowY: "auto" }}
    >
      <div className="d-flex justify-content-center align-items-start position-relative">
        {/* Phần nội dung chính */}
        <div className="col-9">
          {/* Header */}
          <div className="col-12 py-4 px-5 text-white bg-primary-subtle">
            <h2>{project.title}</h2>
            <p>{project.description}</p>
            <p><strong>Trạng thái:</strong> {project.status}</p>
            {project.User && (
              <p><strong>Người tạo:</strong> {project.User.username}</p>
            )}
          </div>

          {/* Ảnh đại diện */}
          {project.imageUrl && (
            <div className="col-12 py-4 text-center bg-light">
              <img
                src={project.imageUrl}
                alt={project.title}
                className="img-fluid rounded"
                style={{ maxHeight: "100vh", objectFit: "cover" }}
              />
            </div>
          )}

          {/* Sections */}
          <div className="p-5 bg-white">
            <h4>Nội dung chi tiết:</h4>
            {sections.length > 0 ? (
              sections.map((section, index) => (
                <div key={section.id || index} className="mb-4">
                  {section.imageUrl && (
                    <img
                      src={section.imageUrl}
                      alt={`section-${index}`}
                      className="img-fluid mb-2"
                    />
                  )}
                  <p>{section.text}</p>
                </div>
              ))
            ) : (
              <p>Không có nội dung chi tiết.</p>
            )}
          </div>
        </div>

        {/* Cột phải có nút sticky */}
        <div className="col-1" style={{ minHeight: "150vh", padding: "1rem" }}>
          <button
            style={{
              position: "sticky",
              top: "20px",
              zIndex: 1000,
              padding: "0.5rem 1rem",
              backgroundColor: "black",
              color: "white",
              border: "none",
              borderRadius: "5px",
              width: "100%",
            }}
            onClick={() => window.location.href = "mailto:your@email.com"}
          >
            Gửi Email
          </button>
        </div>

        {/* Nút đóng */}
        <button
          className="btn btn-light position-absolute top-0 end-0 m-4"
          onClick={onClose}
        >
          &times;
        </button>
      </div>
    </div>
  );
}
